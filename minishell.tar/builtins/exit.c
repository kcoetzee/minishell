#include "../main.h"

void    run_builtin_exit(char **argv, char **envp)
{
	debug("running run_builtin_exit");
	exit(0);
}
